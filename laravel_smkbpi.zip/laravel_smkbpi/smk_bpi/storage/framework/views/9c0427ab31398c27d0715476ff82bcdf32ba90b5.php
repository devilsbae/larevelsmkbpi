<html>
<head>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <title>Gallery</title>
</head>
<body>

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="/siswa"> Data Siswa </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/guru"> Data Guru </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/gallery"> Gallery </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container text-center mt-4">
    <img src="monkey-selfie_custom-7117031c832fc3607ee5b26b9d5b03d10a1deaca-s1100-c50.jpg" width="200">
    </div>

    <footer class="bg-dark py-4 text-white mt-4">
        <div class="container">
            Gallery | copyright &#169; <?php echo e(date("Y")); ?> Radhiya
        </div>
    </footer>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel_smkbpi\smk_bpi\resources\views/gallery.blade.php ENDPATH**/ ?>